<html>
    <head>
    
    </head>
    <body>
        <a href="z.test.php?id=1">Peter Griffin</a>
        <a href="z.test.php?id=2">Homer Simpson</a>
        
        <div class="the-return">
        </div>
        
         
        
    </body>
</html>
