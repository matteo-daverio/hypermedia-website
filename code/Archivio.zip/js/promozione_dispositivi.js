//select the right text in the menu
$('#menu_promozioni').addClass('current');