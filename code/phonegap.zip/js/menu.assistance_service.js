//when page is complete select the current item of the menu
$("document").ready(function(){ $('#menu_assistenza').addClass('current');});