//async ajax request
$("document").ready(function(){
    //select the right text in the menu
    $('#menu_prodotti').addClass('current');
});




